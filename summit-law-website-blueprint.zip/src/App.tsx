import React, { useState, useEffect } from 'react';

// Types
interface PracticeArea {
  id: string;
  title: string;
  description: string;
  icon: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW' | 'CUSTOM';
}

interface TeamMember {
  id: string;
  name: string;
  title: string;
  bio: string;
  image: string;
  isPrincipal: boolean;
}

interface Office {
  id: string;
  city: string;
  address: string;
  phone: string;
  email: string;
  hours: string;
}

interface Testimonial {
  id: string;
  name: string;
  caseType: string;
  quote: string;
  rating: number;
}

// Data
const practiceAreas: PracticeArea[] = [
  { id: 'corporate', title: 'Corporate & Commercial', description: 'Business formation, mergers, acquisitions, and commercial transactions', icon: '🏢', priority: 'HIGH' },
  { id: 'real-estate', title: 'Real Estate & Property', description: 'Property transactions, leasing, development, and land use', icon: '🏠', priority: 'HIGH' },
  { id: 'employment', title: 'Employment & Labor', description: 'Workplace disputes, contracts, compliance, and labor relations', icon: '👥', priority: 'HIGH' },
  { id: 'intellectual-property', title: 'Intellectual Property', description: 'Patents, trademarks, copyrights, and IP protection', icon: '💡', priority: 'HIGH' },
  { id: 'civil-litigation', title: 'Civil Litigation', description: 'Dispute resolution, court representation, and legal advocacy', icon: '⚖️', priority: 'HIGH' },
  { id: 'banking', title: 'Banking & Finance', description: 'Financial regulations, banking compliance, and investment law', icon: '🏦', priority: 'HIGH' },
  { id: 'constitutional', title: 'Constitutional Law', description: 'Constitutional rights, government law, and civil liberties', icon: '📜', priority: 'HIGH' },
  { id: 'human-rights', title: 'Human Rights Law', description: 'Human rights protection, advocacy, and international law', icon: '🤝', priority: 'HIGH' },
  { id: 'immigration', title: 'Immigration Law', description: 'Visas, citizenship, work permits, and immigration compliance', icon: '🌍', priority: 'MEDIUM' },
  { id: 'personal-injury', title: 'Personal Injury', description: 'Accident claims, compensation, and injury litigation', icon: '🚑', priority: 'MEDIUM' },
  { id: 'wills-estates', title: 'Wills & Estates', description: 'Estate planning, wills, trusts, and probate', icon: '📋', priority: 'MEDIUM' },
  { id: 'tax', title: 'Tax Law', description: 'Tax planning, compliance, disputes, and advisory', icon: '💰', priority: 'MEDIUM' },
  { id: 'criminal', title: 'Criminal Law', description: 'Criminal defense, representation, and legal protection', icon: '🔒', priority: 'LOW' },
  { id: 'medical-malpractice', title: 'Medical Malpractice', description: 'Medical negligence, healthcare law, and patient rights', icon: '🏥', priority: 'LOW' },
  { id: 'customary-arbitration', title: 'Customary Arbitration', description: 'Traditional dispute resolution and customary law', icon: '🏛️', priority: 'CUSTOM' },
];

const teamMembers: TeamMember[] = [
  { id: '1', name: 'Chief Adebayo Okonkwo, SAN', title: 'Principal Lawyer & Managing Partner', bio: '35+ years of legal excellence. Called to the Nigerian Bar in 1990. Specializes in Corporate Law and Constitutional Law.', image: '/images/team-photo.jpg', isPrincipal: true },
  { id: '2', name: 'Barr. Fatima Ibrahim', title: 'Senior Associate', bio: '15 years experience in Employment Law and Human Rights. LL.M from University of Lagos.', image: '/images/team-photo.jpg', isPrincipal: false },
  { id: '3', name: 'Barr. Chukwuma Okafor', title: 'Senior Associate', bio: '12 years experience in Real Estate and Banking Law. Member of Nigerian Bar Association.', image: '/images/team-photo.jpg', isPrincipal: false },
  { id: '4', name: 'Barr. Amaka Nwosu', title: 'Associate', bio: '8 years experience in Intellectual Property and Commercial Law. LL.B from University of Nigeria.', image: '/images/team-photo.jpg', isPrincipal: false },
  { id: '5', name: 'Barr. Yusuf Mohammed', title: 'Associate', bio: '6 years experience in Civil Litigation and Constitutional Law. Called to Bar in 2018.', image: '/images/team-photo.jpg', isPrincipal: false },
];

const offices: Office[] = [
  { id: 'abuja', city: 'Abuja (Head Office)', address: 'Plot 234, Central Business District, Abuja', phone: '+234 809 360 5871', email: 'abuja@summitlawfirm.com', hours: 'Mon-Fri: 8:00 AM - 6:00 PM' },
  { id: 'lagos', city: 'Lagos', address: '15 Victoria Island Way, Lagos', phone: '+234 809 360 5872', email: 'lagos@summitlawfirm.com', hours: 'Mon-Fri: 8:00 AM - 6:00 PM' },
  { id: 'ph', city: 'Port Harcourt', address: '45 Trans Amadi Industrial Layout, Port Harcourt', phone: '+234 809 360 5873', email: 'ph@summitlawfirm.com', hours: 'Mon-Fri: 8:00 AM - 6:00 PM' },
  { id: 'kano', city: 'Kano', address: '12 Ibrahim Taiwo Road, Kano', phone: '+234 809 360 5874', email: 'kano@summitlawfirm.com', hours: 'Mon-Fri: 8:00 AM - 6:00 PM' },
];

const testimonials: Testimonial[] = [
  { id: '1', name: 'Alhaji M. Bello', caseType: 'Corporate Law', quote: 'Summit Law Firm handled our merger with exceptional professionalism. Their expertise saved us millions.', rating: 5 },
  { id: '2', name: 'Mrs. Chioma Okoro', caseType: 'Real Estate', quote: 'They made our property acquisition seamless. Highly recommend their real estate team.', rating: 5 },
  { id: '3', name: 'Dr. James Adeyemi', caseType: 'Employment Law', quote: 'Excellent guidance on our employment contracts. Very knowledgeable and responsive.', rating: 5 },
];

// Components
const Header: React.FC<{ currentPage: string; setCurrentPage: (page: string) => void }> = ({ currentPage, setCurrentPage }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-black shadow-lg' : 'bg-black/95'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentPage('home')}>
            <img src="/images/logo.png" alt="Summit Law Firm" className="h-12 w-auto" />
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold text-yellow-400 font-serif">Summit Law Firm</h1>
              <p className="text-xs text-gray-300">Excellence Since 1990</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {['Home', 'About', 'Team', 'Practice Areas', 'Contact'].map((item) => (
              <button
                key={item}
                onClick={() => setCurrentPage(item.toLowerCase().replace(' ', '-'))}
                className={`text-sm font-medium transition-colors ${
                  currentPage === item.toLowerCase().replace(' ', '-') 
                    ? 'text-yellow-400' 
                    : 'text-white hover:text-yellow-400'
                }`}
              >
                {item}
              </button>
            ))}
          </nav>

          {/* WhatsApp Button */}
          <a
            href="https://wa.me/2348093605871"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center space-x-2 bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold hover:bg-yellow-500 transition-colors"
          >
            <span>📞</span>
            <span>+234 809 360 5871</span>
          </a>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden text-white p-2"
          >
            <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-black border-t border-gray-800 py-4">
            <nav className="flex flex-col space-y-4">
              {['Home', 'About', 'Team', 'Practice Areas', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => {
                    setCurrentPage(item.toLowerCase().replace(' ', '-'));
                    setMobileMenuOpen(false);
                  }}
                  className="text-left text-white hover:text-yellow-400 px-4 py-2"
                >
                  {item}
                </button>
              ))}
              <a
                href="https://wa.me/2348093605871"
                className="flex items-center space-x-2 bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold mx-4"
              >
                <span>📞</span>
                <span>+234 809 360 5871</span>
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

const Footer: React.FC<{ setCurrentPage: (page: string) => void }> = ({ setCurrentPage }) => {
  return (
    <footer className="bg-black text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Office Locations */}
          <div>
            <h3 className="text-yellow-400 font-serif text-lg font-bold mb-4">Our Offices</h3>
            <ul className="space-y-3">
              {offices.map((office) => (
                <li key={office.id} className="text-gray-300 text-sm">
                  <strong className="text-white">{office.city}</strong>
                  <br />
                  {office.phone}
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-yellow-400 font-serif text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {['Home', 'About Us', 'Our Team', 'Practice Areas', 'Contact'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => setCurrentPage(item.toLowerCase().replace(' ', '-'))}
                    className="text-gray-300 hover:text-yellow-400 text-sm transition-colors"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Practice Areas */}
          <div>
            <h3 className="text-yellow-400 font-serif text-lg font-bold mb-4">Practice Areas</h3>
            <ul className="space-y-2">
              {practiceAreas.slice(0, 6).map((area) => (
                <li key={area.id}>
                  <button
                    onClick={() => setCurrentPage(`practice-${area.id}`)}
                    className="text-gray-300 hover:text-yellow-400 text-sm transition-colors"
                  >
                    {area.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-yellow-400 font-serif text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-gray-300 text-sm">
              <li>📧 info@summitlawfirm.com</li>
              <li>📞 +234 809 360 5871</li>
              <li>🕐 Mon-Fri: 8:00 AM - 6:00 PM</li>
              <li>📍 Abuja, Lagos, PH, Kano</li>
            </ul>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-yellow-400 text-xl">📘</a>
              <a href="#" className="text-gray-300 hover:text-yellow-400 text-xl">📸</a>
              <a href="#" className="text-gray-300 hover:text-yellow-400 text-xl">🐦</a>
              <a href="#" className="text-gray-300 hover:text-yellow-400 text-xl">💼</a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2026 Summit Law Firm. All Rights Reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <button onClick={() => setCurrentPage('privacy')} className="text-gray-400 hover:text-yellow-400 text-sm">Privacy Policy</button>
            <button onClick={() => setCurrentPage('terms')} className="text-gray-400 hover:text-yellow-400 text-sm">Terms & Conditions</button>
            <button onClick={() => setCurrentPage('disclaimer')} className="text-gray-400 hover:text-yellow-400 text-sm">Disclaimer</button>
          </div>
        </div>
      </div>
    </footer>
  );
};

const WhatsAppButton: React.FC = () => {
  return (
    <a
      href="https://wa.me/2348093605871"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-all hover:scale-110 animate-pulse"
      title="Chat on WhatsApp"
    >
      <span className="text-3xl">💬</span>
    </a>
  );
};

// Page Components
const HomePage: React.FC<{ setCurrentPage: (page: string) => void }> = ({ setCurrentPage }) => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: 'url(/images/hero-bg.jpg)' }}>
        <div className="absolute inset-0 bg-black/70"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-yellow-400 font-serif mb-6">
            Summit Law Firm
          </h1>
          <p className="text-xl md:text-2xl text-white mb-4">
            Excellence in Legal Service Since 1990
          </p>
          <p className="text-lg text-gray-300 mb-8">
            35+ Years of Trusted Legal Excellence Across Nigeria
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setCurrentPage('contact')}
              className="bg-yellow-400 text-black px-8 py-4 rounded-lg font-bold text-lg hover:bg-yellow-500 transition-colors"
            >
              Free Consultation
            </button>
            <a
              href="https://wa.me/2348093605871"
              className="bg-green-500 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
            >
              <span>💬</span> WhatsApp Us
            </a>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-yellow-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl md:text-5xl font-bold text-black">35+</p>
              <p className="text-black font-medium">Years Experience</p>
            </div>
            <div>
              <p className="text-4xl md:text-5xl font-bold text-black">5000+</p>
              <p className="text-black font-medium">Cases Handled</p>
            </div>
            <div>
              <p className="text-4xl md:text-5xl font-bold text-black">98%</p>
              <p className="text-black font-medium">Success Rate</p>
            </div>
            <div>
              <p className="text-4xl md:text-5xl font-bold text-black">4</p>
              <p className="text-black font-medium">Office Locations</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-black font-serif mb-6">
                About Summit Law Firm
              </h2>
              <p className="text-gray-700 mb-4">
                Since 1990, Summit Law Firm has been at the forefront of legal excellence in Nigeria. 
                Our team of experienced lawyers is dedicated to providing exceptional legal services 
                across multiple practice areas.
              </p>
              <p className="text-gray-700 mb-6">
                With offices in Abuja, Lagos, Port Harcourt, and Kano, we serve clients nationwide 
                with professionalism, integrity, and results-driven advocacy.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-700">
                  <span className="text-yellow-400 mr-3">✓</span>
                  35+ Years of Legal Excellence
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-yellow-400 mr-3">✓</span>
                  Multilingual Team (English, Hausa, Yoruba)
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-yellow-400 mr-3">✓</span>
                  Free Initial Consultation
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-yellow-400 mr-3">✓</span>
                  4 Strategic Office Locations
                </li>
              </ul>
              <button
                onClick={() => setCurrentPage('about')}
                className="bg-black text-yellow-400 px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition-colors"
              >
                Learn More
              </button>
            </div>
            <div>
              <img src="/images/office-building.jpg" alt="Summit Law Firm Office" className="rounded-lg shadow-xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Practice Areas */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-black font-serif mb-4">
              Our Practice Areas
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Comprehensive legal services across 15 practice areas, serving individuals and businesses nationwide.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {practiceAreas.slice(0, 6).map((area) => (
              <button
                key={area.id}
                onClick={() => setCurrentPage(`practice-${area.id}`)}
                className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow text-left border-l-4 border-yellow-400"
              >
                <span className="text-4xl mb-4 block">{area.icon}</span>
                <h3 className="text-xl font-bold text-black mb-2">{area.title}</h3>
                <p className="text-gray-600">{area.description}</p>
              </button>
            ))}
          </div>
          <div className="text-center mt-8">
            <button
              onClick={() => setCurrentPage('practice-areas')}
              className="bg-black text-yellow-400 px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition-colors"
            >
              View All Practice Areas
            </button>
          </div>
        </div>
      </section>

      {/* Team Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-black font-serif mb-4">
              Meet Our Lawyers
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our team of experienced legal professionals is dedicated to your success.
            </p>
          </div>
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
            {teamMembers.map((member) => (
              <div key={member.id} className="text-center">
                <img src={member.image} alt={member.name} className="w-full h-48 object-cover rounded-lg mb-4" />
                <h3 className="font-bold text-black">{member.name}</h3>
                <p className="text-gray-600 text-sm">{member.title}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <button
              onClick={() => setCurrentPage('team')}
              className="bg-black text-yellow-400 px-6 py-3 rounded-lg font-semibold hover:bg-gray-800 transition-colors"
            >
              View Full Team
            </button>
          </div>
        </div>
      </section>

      {/* Offices */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-black font-serif mb-4">
              Our Locations
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Four strategic offices across Nigeria to serve you better.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {offices.map((office) => (
              <div key={office.id} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-black mb-2">{office.city}</h3>
                <p className="text-gray-600 text-sm mb-4">{office.address}</p>
                <p className="text-gray-700 font-semibold">{office.phone}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-yellow-400 font-serif mb-12">
            Client Testimonials
          </h2>
          <div className="bg-gray-900 p-8 rounded-lg">
            <p className="text-2xl italic mb-6">"{testimonials[currentTestimonial].quote}"</p>
            <p className="text-yellow-400 font-bold">— {testimonials[currentTestimonial].name}</p>
            <p className="text-gray-400">{testimonials[currentTestimonial].caseType}</p>
            <div className="flex justify-center mt-4">
              {'⭐'.repeat(testimonials[currentTestimonial].rating)}
            </div>
          </div>
          <div className="flex justify-center mt-6 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`w-3 h-3 rounded-full ${index === currentTestimonial ? 'bg-yellow-400' : 'bg-gray-600'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-black font-serif mb-6">
            Ready to Discuss Your Case?
          </h2>
          <p className="text-black mb-8">
            Contact us today for a free consultation. Our team is ready to help you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setCurrentPage('contact')}
              className="bg-black text-yellow-400 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-800 transition-colors"
            >
              Contact Us
            </button>
            <a
              href="https://wa.me/2348093605871"
              className="bg-green-500 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
            >
              <span>💬</span> WhatsApp Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

const AboutPage: React.FC = () => {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-yellow-400 font-serif mb-4">
            About Summit Law Firm
          </h1>
          <p className="text-xl text-gray-300">35 Years of Legal Excellence</p>
        </div>
      </section>

      {/* History */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-black font-serif mb-6">Our History</h2>
              <div className="space-y-6">
                <div className="border-l-4 border-yellow-400 pl-4">
                  <p className="font-bold text-yellow-400">1990</p>
                  <p className="text-gray-700">Summit Law Firm founded by Chief Adebayo Okonkwo, SAN</p>
                </div>
                <div className="border-l-4 border-yellow-400 pl-4">
                  <p className="font-bold text-yellow-400">1995</p>
                  <p className="text-gray-700">Expanded to Lagos with second office</p>
                </div>
                <div className="border-l-4 border-yellow-400 pl-4">
                  <p className="font-bold text-yellow-400">2005</p>
                  <p className="text-gray-700">Opened Port Harcourt office</p>
                </div>
                <div className="border-l-4 border-yellow-400 pl-4">
                  <p className="font-bold text-yellow-400">2015</p>
                  <p className="text-gray-700">Kano office established</p>
                </div>
                <div className="border-l-4 border-yellow-400 pl-4">
                  <p className="font-bold text-yellow-400">2026</p>
                  <p className="text-gray-700">Celebrating 35+ years of excellence</p>
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-black font-serif mb-6">Mission & Vision</h2>
              <div className="bg-gray-50 p-6 rounded-lg mb-6">
                <h3 className="text-xl font-bold text-yellow-400 mb-3">Our Mission</h3>
                <p className="text-gray-700">
                  To provide exceptional legal services with integrity, professionalism, and dedication, 
                  ensuring justice and protection for all our clients across Nigeria.
                </p>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-xl font-bold text-yellow-400 mb-3">Our Vision</h3>
                <p className="text-gray-700">
                  To be the leading law firm in Nigeria, recognized for excellence, innovation, 
                  and unwavering commitment to client success.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-black font-serif text-center mb-12">Our Core Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: 'Integrity', desc: 'We uphold the highest ethical standards in all our dealings' },
              { title: 'Excellence', desc: 'We strive for excellence in every case and client interaction' },
              { title: 'Professionalism', desc: 'We maintain professional conduct at all times' },
              { title: 'Client-Focused', desc: 'Your success is our priority' },
              { title: 'Innovation', desc: 'We embrace modern legal practices and technology' },
              { title: 'Accessibility', desc: 'We make legal services accessible to all Nigerians' },
            ].map((value, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-yellow-400 mb-3">{value.title}</h3>
                <p className="text-gray-700">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-black font-serif text-center mb-12">Why Choose Summit Law Firm?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: '🏆', title: '35+ Years Experience', desc: 'Decades of legal expertise' },
              { icon: '👨‍⚖️', title: 'Expert Lawyers', desc: 'Qualified and experienced team' },
              { icon: '📊', title: '5000+ Cases', desc: 'Proven track record' },
              { icon: '✅', title: '98% Success Rate', desc: 'Results that speak' },
              { icon: '🌍', title: '4 Offices', desc: 'Nationwide presence' },
              { icon: '💬', title: 'Multilingual', desc: 'English, Hausa, Yoruba' },
            ].map((item, index) => (
              <div key={index} className="text-center p-6">
                <span className="text-5xl mb-4 block">{item.icon}</span>
                <h3 className="text-xl font-bold text-black mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-black font-serif mb-6">Schedule a Consultation</h2>
          <p className="text-black mb-8">Let us help you with your legal needs</p>
          <a
            href="https://wa.me/2348093605871"
            className="bg-black text-yellow-400 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-800 transition-colors inline-block"
          >
            Contact Us Today
          </a>
        </div>
      </section>
    </div>
  );
};

const TeamPage: React.FC = () => {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-yellow-400 font-serif mb-4">
            Our Legal Team
          </h1>
          <p className="text-xl text-gray-300">Expert Lawyers Dedicated to Your Success</p>
        </div>
      </section>

      {/* Principal Lawyer */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <img src={teamMembers[0].image} alt={teamMembers[0].name} className="rounded-lg shadow-xl" />
            <div>
              <h2 className="text-3xl font-bold text-black font-serif mb-2">{teamMembers[0].name}</h2>
              <p className="text-yellow-400 font-bold mb-4">{teamMembers[0].title}</p>
              <p className="text-gray-700 mb-4">{teamMembers[0].bio}</p>
              <div className="space-y-2 text-gray-600">
                <p><strong>Education:</strong> LL.B, LL.M, SAN</p>
                <p><strong>Bar Admission:</strong> 1990</p>
                <p><strong>Specializations:</strong> Corporate Law, Constitutional Law</p>
                <p><strong>Email:</strong> okonkwo@summitlawfirm.com</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Associate Lawyers */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-black font-serif text-center mb-12">Associate Lawyers</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.slice(1).map((member) => (
              <div key={member.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img src={member.image} alt={member.name} className="w-full h-64 object-cover" />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-black mb-2">{member.name}</h3>
                  <p className="text-yellow-400 font-semibold mb-3">{member.title}</p>
                  <p className="text-gray-600 text-sm mb-4">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-black text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-yellow-400 font-serif mb-6">Work With Our Team</h2>
          <p className="text-gray-300 mb-8">Our experienced lawyers are ready to assist you</p>
          <a
            href="https://wa.me/2348093605871"
            className="bg-yellow-400 text-black px-8 py-4 rounded-lg font-bold text-lg hover:bg-yellow-500 transition-colors inline-block"
          >
            Contact Us
          </a>
        </div>
      </section>
    </div>
  );
};

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    practiceArea: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-yellow-400 font-serif mb-4">
            Contact Us
          </h1>
          <p className="text-xl text-gray-300">Get in Touch with Our Legal Team</p>
        </div>
      </section>

      {/* Contact Info & Form */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div>
              <h2 className="text-2xl font-bold text-black font-serif mb-6">Contact Information</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="font-bold text-yellow-400 mb-2">📞 Phone Numbers</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>Abuja: +234 809 360 5871</li>
                    <li>Lagos: +234 809 360 5872</li>
                    <li>Port Harcourt: +234 809 360 5873</li>
                    <li>Kano: +234 809 360 5874</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold text-yellow-400 mb-2">📧 Email Addresses</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li>General: info@summitlawfirm.com</li>
                    <li>Abuja: abuja@summitlawfirm.com</li>
                    <li>Lagos: lagos@summitlawfirm.com</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold text-yellow-400 mb-2">🕐 Working Hours</h3>
                  <p className="text-gray-700">Monday - Friday: 8:00 AM - 6:00 PM</p>
                  <p className="text-gray-700">Saturday: 10:00 AM - 2:00 PM</p>
                  <p className="text-gray-700">Sunday: Closed</p>
                </div>
                <div>
                  <h3 className="font-bold text-yellow-400 mb-2">💬 Emergency Contact</h3>
                  <p className="text-gray-700">+234 809 360 5871 (24/7)</p>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold text-black font-serif mb-6">Send Us a Message</h2>
              {submitted ? (
                <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                  Thank you! We'll contact you within 24 hours.
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-400"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-400"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-400"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Practice Area *</label>
                    <select
                      required
                      value={formData.practiceArea}
                      onChange={(e) => setFormData({ ...formData, practiceArea: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-400"
                    >
                      <option value="">Select a practice area</option>
                      {practiceAreas.map((area) => (
                        <option key={area.id} value={area.id}>{area.title}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 font-semibold mb-2">Message *</label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-400"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-yellow-400 text-black px-6 py-3 rounded-lg font-bold hover:bg-yellow-500 transition-colors"
                  >
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Office Locations */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-black font-serif text-center mb-12">Our Office Locations</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {offices.map((office) => (
              <div key={office.id} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-black mb-3">{office.city}</h3>
                <p className="text-gray-600 text-sm mb-3">{office.address}</p>
                <p className="text-gray-700 font-semibold mb-1">{office.phone}</p>
                <p className="text-gray-600 text-sm mb-3">{office.email}</p>
                <p className="text-gray-600 text-sm">{office.hours}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-black font-serif mb-6">Ready to Discuss Your Case?</h2>
          <p className="text-black mb-8">Contact us today for a free consultation</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/2348093605871"
              className="bg-black text-yellow-400 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-800 transition-colors inline-block"
            >
              WhatsApp Us
            </a>
            <a
              href="tel:+2348093605871"
              className="bg-green-500 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-green-600 transition-colors inline-block"
            >
              Call Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

const PracticeAreasPage: React.FC<{ setCurrentPage: (page: string) => void }> = ({ setCurrentPage }) => {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-yellow-400 font-serif mb-4">
            Practice Areas
          </h1>
          <p className="text-xl text-gray-300">Comprehensive Legal Services Across 15 Practice Areas</p>
        </div>
      </section>

      {/* All Practice Areas */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* HIGH Priority */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-black font-serif mb-8 border-b-4 border-yellow-400 inline-block">
              Core Practice Areas
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {practiceAreas.filter(p => p.priority === 'HIGH').map((area) => (
                <button
                  key={area.id}
                  onClick={() => setCurrentPage(`practice-${area.id}`)}
                  className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow text-left border-l-4 border-yellow-400"
                >
                  <span className="text-4xl mb-4 block">{area.icon}</span>
                  <h3 className="text-xl font-bold text-black mb-2">{area.title}</h3>
                  <p className="text-gray-600">{area.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* MEDIUM Priority */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-black font-serif mb-8 border-b-4 border-yellow-400 inline-block">
              Additional Services
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {practiceAreas.filter(p => p.priority === 'MEDIUM').map((area) => (
                <button
                  key={area.id}
                  onClick={() => setCurrentPage(`practice-${area.id}`)}
                  className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow text-left border-l-4 border-yellow-400"
                >
                  <span className="text-4xl mb-4 block">{area.icon}</span>
                  <h3 className="text-xl font-bold text-black mb-2">{area.title}</h3>
                  <p className="text-gray-600">{area.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* LOW + CUSTOM */}
          <div>
            <h2 className="text-2xl font-bold text-black font-serif mb-8 border-b-4 border-yellow-400 inline-block">
              Specialized Services
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {practiceAreas.filter(p => p.priority === 'LOW' || p.priority === 'CUSTOM').map((area) => (
                <button
                  key={area.id}
                  onClick={() => setCurrentPage(`practice-${area.id}`)}
                  className="bg-gray-50 p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow text-left border-l-4 border-yellow-400"
                >
                  <span className="text-4xl mb-4 block">{area.icon}</span>
                  <h3 className="text-xl font-bold text-black mb-2">{area.title}</h3>
                  <p className="text-gray-600">{area.description}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-black font-serif mb-6">Need Legal Assistance?</h2>
          <p className="text-black mb-8">Our experts are ready to help you</p>
          <a
            href="https://wa.me/2348093605871"
            className="bg-black text-yellow-400 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-800 transition-colors inline-block"
          >
            Contact Us Today
          </a>
        </div>
      </section>
    </div>
  );
};

const PracticeAreaDetail: React.FC<{ areaId: string; setCurrentPage: (page: string) => void }> = ({ areaId, setCurrentPage }) => {
  const area = practiceAreas.find(p => p.id === areaId);
  
  if (!area) {
    return <div className="pt-20">Practice area not found</div>;
  }

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => setCurrentPage('practice-areas')}
            className="text-yellow-400 mb-4 hover:underline"
          >
            ← Back to Practice Areas
          </button>
          <h1 className="text-4xl md:text-5xl font-bold text-yellow-400 font-serif mb-4">
            {area.title}
          </h1>
          <p className="text-xl text-gray-300">{area.description}</p>
        </div>
      </section>

      {/* Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-black font-serif mb-6">About {area.title}</h2>
              <p className="text-gray-700 mb-4">
                At Summit Law Firm, our {area.title.toLowerCase()} practice is led by experienced lawyers 
                who understand the complexities of Nigerian law. We provide comprehensive legal services 
                tailored to meet the unique needs of each client.
              </p>
              <p className="text-gray-700 mb-4">
                With over 35 years of combined experience, our team has successfully handled thousands 
                of cases in this practice area, delivering results that exceed expectations.
              </p>
              <p className="text-gray-700">
                Whether you're an individual seeking legal protection or a business requiring 
                strategic counsel, our {area.title.toLowerCase()} lawyers are here to help.
              </p>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-black font-serif mb-6">Our Services</h2>
              <ul className="space-y-3">
                {[
                  'Legal Consultation & Advisory',
                  'Case Assessment & Strategy',
                  'Document Preparation & Review',
                  'Negotiation & Mediation',
                  'Court Representation',
                  'Compliance & Risk Management',
                ].map((service, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-yellow-400 mr-3">✓</span>
                    <span className="text-gray-700">{service}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-black font-serif text-center mb-12">
            Why Choose Summit Law Firm for {area.title}?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: 'Specialized Expertise', desc: 'Deep knowledge in this practice area' },
              { title: 'Proven Track Record', desc: 'Successful case outcomes' },
              { title: 'Personalized Attention', desc: 'Dedicated lawyer for your case' },
              { title: 'Cost-Effective', desc: 'Transparent pricing' },
              { title: 'Quick Response', desc: 'Timely communication' },
              { title: 'Multilingual Support', desc: 'English, Hausa, Yoruba' },
            ].map((item, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold text-yellow-400 mb-3">{item.title}</h3>
                <p className="text-gray-700">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-yellow-400">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-black font-serif mb-6">
            Free Consultation for {area.title}
          </h2>
          <p className="text-black mb-8">Discuss your case with our experts today</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setCurrentPage('contact')}
              className="bg-black text-yellow-400 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-800 transition-colors"
            >
              Contact Us
            </button>
            <a
              href="https://wa.me/2348093605871"
              className="bg-green-500 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
            >
              <span>💬</span> WhatsApp Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

const FAQPage: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    { q: 'How do I schedule a consultation?', a: 'You can schedule a consultation by calling us at +234 809 360 5871, sending a WhatsApp message, or filling out our contact form. We offer free initial consultations.' },
    { q: 'What are your fees?', a: 'Our fees vary depending on the type of case and complexity. We offer transparent pricing and will provide a fee estimate during your initial consultation.' },
    { q: 'Do you offer payment plans?', a: 'Yes, we understand that legal services can be expensive. We offer flexible payment plans for qualifying clients.' },
    { q: 'How long will my case take?', a: 'The duration of a case depends on many factors including the type of case, court schedules, and complexity. We will provide an estimated timeline during your consultation.' },
    { q: 'What documents should I bring?', a: 'Bring all relevant documents related to your case, including contracts, correspondence, court papers, and any evidence. We will advise you on specific documents needed.' },
    { q: 'Do you handle cases outside Abuja?', a: 'Yes, we have offices in Abuja, Lagos, Port Harcourt, and Kano. We handle cases nationwide.' },
    { q: 'Can you represent me in court?', a: 'Yes, our lawyers are called to the Nigerian Bar and can represent you in all courts across Nigeria.' },
    { q: 'Is my consultation confidential?', a: 'Yes, all consultations are strictly confidential and protected by attorney-client privilege.' },
  ];

  return (
    <div className="pt-20">
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-yellow-400 font-serif mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-300">Find answers to common questions</p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-gray-200 rounded-lg">
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full px-6 py-4 text-left flex justify-between items-center bg-gray-50 hover:bg-gray-100"
                >
                  <span className="font-semibold text-black">{faq.q}</span>
                  <span className="text-yellow-400 text-2xl">{openIndex === index ? '−' : '+'}</span>
                </button>
                {openIndex === index && (
                  <div className="px-6 py-4 text-gray-700">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

const LegalPage: React.FC<{ title: string; content: string }> = ({ title, content }) => {
  return (
    <div className="pt-20">
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-yellow-400 font-serif mb-4">{title}</h1>
        </div>
      </section>
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="prose max-w-none">
            <p className="text-gray-700 whitespace-pre-line">{content}</p>
          </div>
        </div>
      </section>
    </div>
  );
};

// Main App Component
const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    if (currentPage === 'home') {
      return <HomePage setCurrentPage={setCurrentPage} />;
    } else if (currentPage === 'about') {
      return <AboutPage />;
    } else if (currentPage === 'team') {
      return <TeamPage />;
    } else if (currentPage === 'contact') {
      return <ContactPage />;
    } else if (currentPage === 'practice-areas') {
      return <PracticeAreasPage setCurrentPage={setCurrentPage} />;
    } else if (currentPage.startsWith('practice-')) {
      const areaId = currentPage.replace('practice-', '');
      return <PracticeAreaDetail areaId={areaId} setCurrentPage={setCurrentPage} />;
    } else if (currentPage === 'faq') {
      return <FAQPage />;
    } else if (currentPage === 'privacy') {
      return <LegalPage title="Privacy Policy" content="Summit Law Firm Privacy Policy

Last Updated: January 2026

1. Introduction
Summit Law Firm is committed to protecting your privacy. This policy explains how we collect, use, and safeguard your information.

2. Information We Collect
- Personal information (name, email, phone)
- Case-related information
- Communication records

3. How We Use Information
- To provide legal services
- To communicate with you
- To improve our services

4. Data Protection
We implement appropriate security measures to protect your information.

5. Your Rights
You have the right to access, correct, or delete your personal information.

6. Contact
For privacy concerns, contact: privacy@summitlawfirm.com" />;
    } else if (currentPage === 'terms') {
      return <LegalPage title="Terms & Conditions" content="Summit Law Firm Terms & Conditions

Last Updated: January 2026

1. Acceptance of Terms
By using our services, you agree to these terms.

2. Services
We provide legal services as described on our website.

3. Fees
Our fees are as agreed upon in our engagement letter.

4. Confidentiality
All communications are confidential and privileged.

5. Limitation of Liability
Our liability is limited to the scope of our engagement.

6. Governing Law
These terms are governed by Nigerian law.

7. Contact
For questions, contact: legal@summitlawfirm.com" />;
    } else if (currentPage === 'disclaimer') {
      return <LegalPage title="Disclaimer" content="Legal Disclaimer

Last Updated: January 2026

1. No Attorney-Client Relationship
Contacting us does not create an attorney-client relationship.

2. General Information Only
Website content is for general information only, not legal advice.

3. Results Not Guaranteed
Past results do not guarantee future outcomes.

4. Professional Advice Required
Consult with a lawyer for specific legal advice.

5. Accuracy
We strive for accuracy but do not guarantee completeness.

6. Contact
For questions, contact: info@summitlawfirm.com" />;
    }
    return <HomePage setCurrentPage={setCurrentPage} />;
  };

  return (
    <div className="min-h-screen bg-white">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main>
        {renderPage()}
      </main>
      <Footer setCurrentPage={setCurrentPage} />
      <WhatsAppButton />
    </div>
  );
};

export default App;
